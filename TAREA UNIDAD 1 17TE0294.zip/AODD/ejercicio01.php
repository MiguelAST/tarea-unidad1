<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ejercicio 01</title>
</head>
<body>
<?php echo 'Hola mundo!'; ?>
</body>
</html>
