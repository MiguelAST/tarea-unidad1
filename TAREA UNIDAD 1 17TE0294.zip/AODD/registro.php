<title>Informacion de usuario</title>
<?php

$nombre = $_POST['nombre'];
$apellidop = $_POST['apellidop'];
$apellidom = $_POST['apellidom'];
$rfc= $_POST['rfc'];
$domicilio= $_POST['domicilio'];
$telefono= $_POST['telefono'];
$correo= $_POST['correo'];
$sexo= $_POST['sexo'];
$fecha = $_POST['fecha'];
$civil= $_POST['civil'];
$escolaridad= $_POST['escolaridad'];
echo "<h2>Informacion de usuario</h2>";
echo "El nombre se llama: " . $nombre . "<br/>";
echo "Apellido Paterno: " . $apellidop . "<br/>";
echo "Apellido Materno: " . $apellidom . "<br/>";
echo " Su RFC: " . $rfc . "<br/>";
echo " Su telefono: " . $telefono . "<br/>";
echo " Su correo eletronico: " . $correo . "<br/>";
echo " Su Genero: " . $sexo . "<br/>";
echo " Su fecha de nacimiento: " . $fecha . "<br/>";
echo " Su estado civil: " . $civil . "<br/>";
echo " Su escolaridad de usuario: " . $escolaridad . "<br/>";
?>

