<html>
<head>
    <title>Datos de usuario</title>
    <meta charset="utf8">
</head>
<body>

<h2>Ingresar los datos de usuario</h2>
<form action="registro.php" method="post">
    
    <p>Nombre:<input type="text" name="nombre"></p>
    <p>Apellido paterno:<input type="text" name="apellidop"></p>
    <p>Apellido materno:<input type="text" name="apellidom"></p>
    <p> RFC:<input type="text" name="rfc"></p>
    <p> Domicilio:<input type="textArea" name="domicilio"></p>
    <p> Telefono:<input type="number" name="telefono"></p>
    <p> Correo eletronico:<input type="text" name="correo"></p>
    <p> Genero:<input type="text" name="sexo"></p>
    <p> Fecha nacimiento:<input type="date" name="fecha"></p>
    <p> Estado civil:<input type="text" name="civil"></p>
    <p> Escolaridad:<input type="text" name="escolaridad"></p>
    <p><input type="submit" value="Enviar datos" /></p>
</form>
<body>
</html>
